package usjt;

public interface Diagonal {
	public double diagonal();
}
