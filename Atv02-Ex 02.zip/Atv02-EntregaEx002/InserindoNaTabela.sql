USE pais;

INSERT INTO paises (nome, populacao, area) VALUES ('Alemanha', 82800000, 357051.00);
INSERT INTO paises (nome, populacao, area) VALUES ('Itália', 60317546, 301340.00);
INSERT INTO paises (nome, populacao, area) VALUES ('Russia', 146745098, 17098246.00);
INSERT INTO paises (nome, populacao, area) VALUES ('China', 1401812360, 9569961.00);
INSERT INTO paises (nome, populacao, area) VALUES ('India', 1359933123, 3287263.00);