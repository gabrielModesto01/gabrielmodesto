package usjt;

public class Trapezio extends Figura {
   @Override
	public double area() {
		return 0;
	}
	@Override
	public double perimetro() {
		return 0;
	}
}
